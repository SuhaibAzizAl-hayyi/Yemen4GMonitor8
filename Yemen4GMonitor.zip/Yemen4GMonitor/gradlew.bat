@rem Gradle startup script for Windows (standard wrapper launcher)
@if "%DEBUG%"=="" @echo off
set DIRNAME=%~dp0
set APP_HOME=%DIRNAME%
set CLASSPATH=%APP_HOME%gradle\wrapper\gradle-wrapper.jar

if not exist "%CLASSPATH%" (
    echo ERROR: gradle\wrapper\gradle-wrapper.jar not found.
    echo This project was generated without network access, so the wrapper jar
    echo could not be downloaded. Install Gradle 8.7 and run "gradle wrapper" once,
    echo or run "gradle" directly using a local Gradle install.
    exit /b 1
)

"%JAVA_HOME%\bin\java.exe" -classpath "%CLASSPATH%" org.gradle.wrapper.GradleWrapperMain %*
