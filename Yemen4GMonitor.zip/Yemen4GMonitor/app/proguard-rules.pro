# Add project specific ProGuard rules here.
-keep class com.suhaib.yemen4gmonitor.data.model.** { *; }
-dontwarn org.jetbrains.annotations.**
