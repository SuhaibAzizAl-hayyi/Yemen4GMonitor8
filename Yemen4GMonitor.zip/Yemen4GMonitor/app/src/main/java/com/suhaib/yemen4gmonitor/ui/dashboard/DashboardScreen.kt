package com.suhaib.yemen4gmonitor.ui.dashboard

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SignalCellularAlt
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.suhaib.yemen4gmonitor.R
import com.suhaib.yemen4gmonitor.data.model.QueryResult
import com.suhaib.yemen4gmonitor.ui.components.InfoCard
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun DashboardScreen(
    result: QueryResult,
    isStale: Boolean,
    onRefresh: () -> Unit,
    onQueryAnother: () -> Unit,
    onOpenSettings: () -> Unit
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.app_name)) },
                actions = {
                    IconButton(onClick = onOpenSettings) {
                        Icon(Icons.Filled.Settings, contentDescription = stringResource(R.string.settings_title))
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .padding(16.dp)
                .fillMaxSize()
                .verticalScroll(rememberScrollStateCompat())
        ) {
            HeaderCard(result = result)

            Spacer(modifier = Modifier.height(16.dp))

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                InfoCard(
                    label = stringResource(R.string.package_label),
                    value = result.packageName ?: stringResource(R.string.value_unavailable),
                    modifier = Modifier.weight(1f)
                )
                InfoCard(
                    label = stringResource(R.string.financial_balance_label),
                    value = result.financialBalance ?: stringResource(R.string.value_unavailable),
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                InfoCard(
                    label = stringResource(R.string.in_network_label),
                    value = result.inNetworkMinutes ?: stringResource(R.string.value_unavailable),
                    modifier = Modifier.weight(1f)
                )
                InfoCard(
                    label = stringResource(R.string.out_network_label),
                    value = result.outNetworkMinutes ?: stringResource(R.string.value_unavailable),
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            InfoCard(
                label = stringResource(R.string.expiry_label),
                value = result.expiryDate ?: stringResource(R.string.value_unavailable),
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(8.dp))

            val updated = SimpleDateFormat("hh:mm a", Locale("ar")).format(Date(result.lastUpdateEpochMillis))
            Text(
                text = if (isStale)
                    stringResource(R.string.stale_data_prefix) + " • " + updated
                else
                    stringResource(R.string.last_updated_prefix) + " " + updated,
                style = MaterialTheme.typography.labelSmall,
                color = if (isStale) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(20.dp))

            Button(
                onClick = onRefresh,
                modifier = Modifier.fillMaxWidth().height(52.dp),
                shape = MaterialTheme.shapes.large
            ) {
                Icon(Icons.Filled.Refresh, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text(stringResource(R.string.refresh_button))
            }

            Spacer(modifier = Modifier.height(10.dp))

            OutlinedButton(
                onClick = onQueryAnother,
                modifier = Modifier.fillMaxWidth().height(52.dp),
                shape = MaterialTheme.shapes.large
            ) {
                Text(stringResource(R.string.query_another_button))
            }
        }
    }
}

@Composable
private fun HeaderCard(result: QueryResult) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = MaterialTheme.shapes.extraLarge,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primary)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.SignalCellularAlt, contentDescription = null, tint = androidx.compose.ui.graphics.Color.White)
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = result.phoneNumber,
                    color = androidx.compose.ui.graphics.Color.White,
                    style = MaterialTheme.typography.titleMedium
                )
            }
            Spacer(modifier = Modifier.height(12.dp))
            Text(
                text = result.dataBalanceRaw ?: stringResource(R.string.value_unavailable),
                color = androidx.compose.ui.graphics.Color.White,
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.ExtraBold
            )
            Text(
                text = stringResource(R.string.remaining_label),
                color = androidx.compose.ui.graphics.Color.White.copy(alpha = 0.85f),
                style = MaterialTheme.typography.bodyMedium
            )
            Spacer(modifier = Modifier.height(12.dp))

            val percent = result.remainingPercent
            if (percent != null) {
                LinearProgressIndicator(
                    progress = { (percent / 100f).toFloat() },
                    modifier = Modifier.fillMaxWidth().height(8.dp),
                    color = androidx.compose.ui.graphics.Color.White,
                    trackColor = androidx.compose.ui.graphics.Color.White.copy(alpha = 0.3f)
                )
            }
        }
    }
}

@Composable
private fun rememberScrollStateCompat() = androidx.compose.foundation.rememberScrollState()
