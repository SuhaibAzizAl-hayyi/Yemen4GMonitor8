package com.suhaib.yemen4gmonitor.ui.theme

import androidx.compose.ui.graphics.Color

// Calm, professional blue / cyan / white palette
val BluePrimary = Color(0xFF1565C0)
val BluePrimaryDark = Color(0xFF64B5F6)
val CyanAccent = Color(0xFF00BCD4)
val SurfaceLight = Color(0xFFF7F9FC)
val SurfaceDark = Color(0xFF10161F)
val CardLight = Color(0xFFFFFFFF)
val CardDark = Color(0xFF1B2330)
val OnSurfaceLight = Color(0xFF14202E)
val OnSurfaceDark = Color(0xFFE7EEF6)
val Success = Color(0xFF2E7D32)
val Warning = Color(0xFFEF6C00)
val ErrorRed = Color(0xFFC62828)
