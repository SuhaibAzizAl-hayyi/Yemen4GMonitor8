package com.suhaib.yemen4gmonitor.data.local

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.doublePreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.suhaib.yemen4gmonitor.data.model.QueryResult
import com.suhaib.yemen4gmonitor.utils.Constants
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = Constants.PREFS_DATASTORE_NAME)

/**
 * Single local source of truth. Nothing here is ever sent to a remote
 * backend -- this app has none. Everything is stored on-device only.
 */
class PreferencesRepository(private val context: Context) {

    private object Keys {
        val SAVED_NUMBER = stringPreferencesKey("saved_number")
        val THEME_MODE = stringPreferencesKey("theme_mode") // light | dark | system

        val R_PHONE = stringPreferencesKey("last_phone")
        val R_PACKAGE = stringPreferencesKey("last_package")
        val R_FINANCIAL = stringPreferencesKey("last_financial")
        val R_IN_NET = stringPreferencesKey("last_in_network")
        val R_OUT_NET = stringPreferencesKey("last_out_network")
        val R_DATA_RAW = stringPreferencesKey("last_data_raw")
        val R_DATA_GB = doublePreferencesKey("last_data_gb")
        val R_TOTAL_GB = doublePreferencesKey("last_total_gb")
        val R_EXPIRY = stringPreferencesKey("last_expiry")
        val R_UPDATED_AT = longPreferencesKey("last_updated_at")
        val R_HAS_RESULT = booleanPreferencesKey("has_result")
    }

    val savedNumberFlow: Flow<String?> =
        context.dataStore.data.map { it[Keys.SAVED_NUMBER] }

    val themeModeFlow: Flow<String> =
        context.dataStore.data.map { it[Keys.THEME_MODE] ?: "system" }

    suspend fun getSavedNumber(): String? = savedNumberFlow.first()

    suspend fun saveNumber(phone: String) {
        context.dataStore.edit { it[Keys.SAVED_NUMBER] = phone }
    }

    suspend fun clearSavedNumber() {
        context.dataStore.edit { it.remove(Keys.SAVED_NUMBER) }
    }

    suspend fun setThemeMode(mode: String) {
        context.dataStore.edit { it[Keys.THEME_MODE] = mode }
    }

    suspend fun saveLastResult(result: QueryResult) {
        context.dataStore.edit { p ->
            p[Keys.R_PHONE] = result.phoneNumber
            result.packageName?.let { p[Keys.R_PACKAGE] = it } ?: p.remove(Keys.R_PACKAGE)
            result.financialBalance?.let { p[Keys.R_FINANCIAL] = it } ?: p.remove(Keys.R_FINANCIAL)
            result.inNetworkMinutes?.let { p[Keys.R_IN_NET] = it } ?: p.remove(Keys.R_IN_NET)
            result.outNetworkMinutes?.let { p[Keys.R_OUT_NET] = it } ?: p.remove(Keys.R_OUT_NET)
            result.dataBalanceRaw?.let { p[Keys.R_DATA_RAW] = it } ?: p.remove(Keys.R_DATA_RAW)
            result.dataBalanceGb?.let { p[Keys.R_DATA_GB] = it } ?: p.remove(Keys.R_DATA_GB)
            result.packageTotalGb?.let { p[Keys.R_TOTAL_GB] = it } ?: p.remove(Keys.R_TOTAL_GB)
            result.expiryDate?.let { p[Keys.R_EXPIRY] = it } ?: p.remove(Keys.R_EXPIRY)
            p[Keys.R_UPDATED_AT] = result.lastUpdateEpochMillis
            p[Keys.R_HAS_RESULT] = true
        }
    }

    suspend fun getLastResult(): QueryResult? {
        val p = context.dataStore.data.first()
        if (p[Keys.R_HAS_RESULT] != true) return null
        val phone = p[Keys.R_PHONE] ?: return null
        return QueryResult(
            phoneNumber = phone,
            packageName = p[Keys.R_PACKAGE],
            financialBalance = p[Keys.R_FINANCIAL],
            inNetworkMinutes = p[Keys.R_IN_NET],
            outNetworkMinutes = p[Keys.R_OUT_NET],
            dataBalanceRaw = p[Keys.R_DATA_RAW],
            dataBalanceGb = p[Keys.R_DATA_GB],
            packageTotalGb = p[Keys.R_TOTAL_GB],
            expiryDate = p[Keys.R_EXPIRY],
            lastUpdateEpochMillis = p[Keys.R_UPDATED_AT] ?: 0L
        )
    }

    companion object {
        @Volatile private var INSTANCE: PreferencesRepository? = null
        fun getInstance(context: Context): PreferencesRepository =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: PreferencesRepository(context.applicationContext).also { INSTANCE = it }
            }
    }
}
