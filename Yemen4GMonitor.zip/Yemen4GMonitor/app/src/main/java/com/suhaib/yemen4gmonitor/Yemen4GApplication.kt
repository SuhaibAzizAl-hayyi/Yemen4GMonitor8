package com.suhaib.yemen4gmonitor

import android.app.Application

class Yemen4GApplication : Application()
