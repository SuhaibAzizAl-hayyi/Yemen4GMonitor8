package com.suhaib.yemen4gmonitor.data.model

/**
 * Represents one successful query result from svc.ptc.gov.ye/4g.
 *
 * All fields are nullable/optional on purpose: the PTC result page does not
 * guarantee every field will be present for every number/package, and this
 * app must never invent a value that wasn't actually returned by the site.
 */
data class QueryResult(
    val phoneNumber: String,
    val packageName: String? = null,
    val financialBalance: String? = null,
    val inNetworkMinutes: String? = null,
    val outNetworkMinutes: String? = null,
    val dataBalanceRaw: String? = null,       // e.g. "13.36 GB" as returned by the site
    val dataBalanceGb: Double? = null,        // parsed numeric value, if extractable
    val packageTotalGb: Double? = null,       // ONLY set if the source confirms the total; never guessed
    val expiryDate: String? = null,
    val lastUpdateEpochMillis: Long = System.currentTimeMillis(),
    val isStale: Boolean = false
) {
    /** Remaining-percentage is only meaningful when the true package size is known. */
    val remainingPercent: Double?
        get() {
            val total = packageTotalGb ?: return null
            val remaining = dataBalanceGb ?: return null
            if (total <= 0.0) return null
            return (remaining / total * 100.0).coerceIn(0.0, 100.0)
        }
}
