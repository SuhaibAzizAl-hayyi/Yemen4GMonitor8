package com.suhaib.yemen4gmonitor.ui.settings

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.suhaib.yemen4gmonitor.BuildConfig
import com.suhaib.yemen4gmonitor.R

@Composable
fun SettingsScreen(
    savedNumber: String?,
    themeMode: String,
    onChangeNumberClick: () -> Unit,
    onForgetNumber: () -> Unit,
    onThemeModeChange: (String) -> Unit,
    onBack: () -> Unit
) {
    var showConfirmForget by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.settings_title)) },
                navigationIcon = {
                    TextButton(onClick = onBack) { Text(stringResource(R.string.back)) }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .padding(20.dp)
                .fillMaxSize()
        ) {
            Text(stringResource(R.string.saved_number_label), style = MaterialTheme.typography.labelLarge)
            Text(
                text = savedNumber ?: stringResource(R.string.no_saved_number),
                style = MaterialTheme.typography.titleLarge
            )
            Spacer(modifier = Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedButton(onClick = onChangeNumberClick) { Text(stringResource(R.string.change_number_button)) }
                if (savedNumber != null) {
                    OutlinedButton(onClick = { showConfirmForget = true }) { Text(stringResource(R.string.forget_number_button)) }
                }
            }

            Spacer(modifier = Modifier.height(28.dp))
            HorizontalDivider()
            Spacer(modifier = Modifier.height(20.dp))

            Text(stringResource(R.string.theme_label), style = MaterialTheme.typography.labelLarge)
            Spacer(modifier = Modifier.height(8.dp))
            ThemeOptionRow(stringResource(R.string.theme_light), selected = themeMode == "light") { onThemeModeChange("light") }
            ThemeOptionRow(stringResource(R.string.theme_dark), selected = themeMode == "dark") { onThemeModeChange("dark") }
            ThemeOptionRow(stringResource(R.string.theme_system), selected = themeMode == "system") { onThemeModeChange("system") }

            Spacer(modifier = Modifier.height(28.dp))
            HorizontalDivider()
            Spacer(modifier = Modifier.height(20.dp))

            Text(stringResource(R.string.about_title), style = MaterialTheme.typography.labelLarge)
            Text(
                text = stringResource(R.string.app_name) + " — " + stringResource(R.string.version_label) + " " + BuildConfig.VERSION_NAME,
                style = MaterialTheme.typography.bodyMedium
            )
        }
    }

    if (showConfirmForget) {
        AlertDialog(
            onDismissRequest = { showConfirmForget = false },
            title = { Text(stringResource(R.string.forget_number_confirm_title)) },
            confirmButton = {
                TextButton(onClick = {
                    showConfirmForget = false
                    onForgetNumber()
                }) { Text(stringResource(R.string.confirm)) }
            },
            dismissButton = {
                TextButton(onClick = { showConfirmForget = false }) { Text(stringResource(R.string.cancel)) }
            }
        )
    }
}

@Composable
private fun ThemeOptionRow(label: String, selected: Boolean, onClick: () -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
    ) {
        RadioButton(selected = selected, onClick = onClick)
        Text(label)
    }
}
