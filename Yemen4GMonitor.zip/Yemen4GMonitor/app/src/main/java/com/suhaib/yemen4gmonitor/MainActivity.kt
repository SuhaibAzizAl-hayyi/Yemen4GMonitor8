package com.suhaib.yemen4gmonitor

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import com.suhaib.yemen4gmonitor.data.repository.Yemen4GRepository
import com.suhaib.yemen4gmonitor.ui.navigation.AppRoot
import com.suhaib.yemen4gmonitor.ui.theme.Yemen4GMonitorTheme
import com.suhaib.yemen4gmonitor.utils.Constants
import androidx.compose.runtime.collectAsState

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // If the widget's "refresh" tap couldn't run silently (no saved number,
        // or CAPTCHA is required), it opens the app with this extra so the user
        // lands straight on the number-entry flow instead of an empty screen.
        val startWithNumberEntry = intent?.getBooleanExtra(Constants.WIDGET_EXTRA_PHONE, false) ?: false

        setContent {
            val context = LocalContext.current
            val repository = remember { Yemen4GRepository.getInstance(context) }
            val themeMode by repository.themeModeFlow.collectAsState(initial = "system")

            Yemen4GMonitorTheme(themeMode = themeMode) {
                Surface(modifier = Modifier.fillMaxSize()) {
                    AppRoot(startWithNumberEntry = startWithNumberEntry)
                }
            }
        }
    }
}
