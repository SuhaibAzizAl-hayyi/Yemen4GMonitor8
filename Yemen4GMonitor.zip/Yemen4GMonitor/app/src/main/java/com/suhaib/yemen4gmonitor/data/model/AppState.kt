package com.suhaib.yemen4gmonitor.data.model

/**
 * The explicit states the Dashboard (and the Widget) can be in. Keeping these
 * as a sealed type means the UI can never silently show "updated" data that
 * wasn't actually fetched.
 */
sealed class AppState {
    data object NoSavedNumber : AppState()
    data object Ready : AppState()
    data object Loading : AppState()
    data object CaptchaRequired : AppState()
    data class Success(val result: QueryResult) : AppState()
    data class Error(val message: String, val lastKnown: QueryResult? = null) : AppState()
    data object Offline : AppState()
    data class StaleData(val lastKnown: QueryResult) : AppState()
}
